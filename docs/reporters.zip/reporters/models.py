from django.db import models
from django.urls import reverse
# from passageidentity import Passage
# import os


class Reporter(models.Model):
    name = models.CharField(max_length=200)
    email = models.CharField(max_length=200, null=True, blank=True)
    receive_updates = models.BooleanField(default=False)

    def __str__(self):
        return self.name
        # returns the model name in the Django admin interface

    def get_api_url(self):
        return reverse("api_reporter", kwargs={"pk": self.id})


# PASSAGE_APP_ID = os.environ.get("PASSAGE_APP_ID")


# class AuthenticationMiddleware(object):
#     def __init__(self, app):
#         self.app = app

#     def __call__(self, environ, start_response):
#         request = Request(environ)
#         psg = Passage(PASSAGE_APP_ID)

#         try:
#             user = psg.authenticateRequest(request)
#         except:
#             ret = Response(u'Authorization failed', mimetype='text/plain', status=401)
#             return ret(environ, start_response)
#         environ['user'] = user
#         return self.app(environ, start_response)
